require('../../modules/es6.number.epsilon');
module.exports = Math.pow(2, -52);
