require('../../modules/es7.math.clamp');
module.exports = require('../../modules/_core').Math.clamp;
