require('../../modules/es7.array.flatten');
module.exports = require('../../modules/_core').Array.flatten;
