require('../../modules/es6.array.of');
module.exports = require('../../modules/_core').Array.of;
